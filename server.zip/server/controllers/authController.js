const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {

  try {

    const { username, email, password, about } = req.body;

    const existingUser = await User.findOne({ email });

    if(existingUser){
      return res.status(400).json({
        message:"User already exists"
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      username,
      email,
      password: hashedPassword,
      about
    });

    res.status(201).json(user);

  } catch (error) {

    res.status(500).json({
      message:error.message
    });

  }
};

exports.login = async (req, res) => {

  try {

    const { email, password } = req.body;

    const user = await User.findOne({ email });

    if(!user){
      return res.status(400).json({
        message:"User not found"
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if(!isMatch){
      return res.status(400).json({
        message:"Invalid credentials"
      });
    }

    const token = jwt.sign(
      { id:user._id },
      "secretkey"
    );

    res.status(200).json({
      token,
      user
    });

  } catch (error) {

    res.status(500).json({
      message:error.message
    });

  }
};